// JavaScript Assignments — All 10
// Results are displayed in the output panel and in the browser console.

function showOutput(message) {
  const output = document.getElementById("output");
  output.textContent = message;
  output.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function getNumber(message) {
  const value = prompt(message);
  if (value === null || value.trim() === "") return null;
  const number = Number(value);
  if (!Number.isFinite(number)) {
    alert("Please enter a valid number.");
    return null;
  }
  return number;
}

// 1. Smart Profile & Birth Year Calculator
function birthYearCalculator() {
  const name = prompt("What is your name?");
  if (name === null || name.trim() === "") return;
  const age = getNumber("What is your current age?");
  if (age === null || age < 0) return;
  const year = getNumber("Enter the current year (e.g. 2026):");
  if (year === null || year < 1) return;

  const birthYear = Math.floor(year - age);
  showOutput(`Hello ${name.trim()}! Your estimated birth year is ${birthYear}.`);
}

// 2. Smart Supermarket Bill Splitter
function billSplitter() {
  const price1 = getNumber("Enter the price of item 1:");
  if (price1 === null || price1 < 0) return;
  const price2 = getNumber("Enter the price of item 2:");
  if (price2 === null || price2 < 0) return;
  const price3 = getNumber("Enter the price of item 3:");
  if (price3 === null || price3 < 0) return;
  const members = getNumber("How many family members will share the bill?");
  if (members === null || !Number.isInteger(members) || members <= 0) {
    alert("Enter a whole number of family members greater than zero.");
    return;
  }

  const total = price1 + price2 + price3;
  const share = total / members;
  showOutput(
    `SUPERMARKET BILL\nItem 1: Rs. ${price1.toFixed(2)}\nItem 2: Rs. ${price2.toFixed(2)}\nItem 3: Rs. ${price3.toFixed(2)}\nTotal bill: Rs. ${total.toFixed(2)}\nEach person's share: Rs. ${share.toFixed(2)}`
  );
}

// 3. Interactive CLI Calculator
function calculator() {
  const first = getNumber("Enter the first number:");
  if (first === null) return;
  const operator = prompt("Enter an operator (+, -, *, /):");
  if (operator === null) return;
  const second = getNumber("Enter the second number:");
  if (second === null) return;

  let result;
  if (operator === "+") {
    result = first + second;
  } else if (operator === "-") {
    result = first - second;
  } else if (operator === "*") {
    result = first * second;
  } else if (operator === "/") {
    if (second === 0) {
      showOutput("Error: Division by zero is not allowed.");
      return;
    }
    result = first / second;
  } else {
    showOutput("Invalid operator. Please use +, -, *, or /.");
    return;
  }
  showOutput(`${first} ${operator} ${second} = ${result}`);
}

// 4. Movie Ticket Discount & VIP Pass System
function ticketSystem() {
  const age = getNumber("Enter your age:");
  if (age === null || age < 0) return;
  const studentAnswer = prompt("Are you a student? (yes/no)");
  if (studentAnswer === null) return;
  const isStudent = studentAnswer.trim().toLowerCase() === "yes";
  const promoCode = prompt("Enter promo code (or leave blank):");
  if (promoCode === null) return;

  const normalPrice = 1000;
  let ticketPrice = normalPrice;
  let message = "";

  if (age < 12) {
    ticketPrice = 300;
    message = "Child ticket price applied.";
  } else {
    if (isStudent) {
      ticketPrice = ticketPrice * 0.80;
      message = "20% student discount applied.";
    } else {
      message = "Standard ticket price applied.";
    }
  }

  let vipMessage = "No VIP backstage pass.";
  if (promoCode.trim().toUpperCase() === "VIP2026") {
    vipMessage = "Congratulations! You receive a VIP backstage pass.";
  }

  showOutput(
    `MOVIE TICKET\n${message}\nTicket price: Rs. ${ticketPrice.toFixed(2)}\n${vipMessage}`
  );
}

// 5. Time-Based Greeting & Schedule Checker
function timeGreeting() {
  const hour = getNumber("Enter the current hour (0 to 23):");
  if (hour === null || !Number.isInteger(hour) || hour < 0 || hour > 23) {
    alert("Please enter a whole number from 0 to 23.");
    return;
  }

  let greeting;
  if (hour >= 5 && hour < 12) {
    greeting = "Good Morning!";
  } else if (hour >= 12 && hour < 17) {
    greeting = "Good Afternoon!";
  } else if (hour >= 17 && hour <= 23) {
    greeting = "Good Evening!";
  } else {
    greeting = "Good Night!";
  }
  showOutput(`Hour: ${hour}:00\n${greeting}`);
}

// 6. Interactive Quiz & Grade System
function quizGame() {
  let score = 0;
  const questions = [
    { question: "What is the capital of Pakistan?", answer: "islamabad" },
    { question: "How many days are there in a week?", answer: "7" },
    { question: "Which planet is known as the Red Planet?", answer: "mars" }
  ];

  for (let i = 0; i < questions.length; i++) {
    const userAnswer = prompt(`Question ${i + 1}: ${questions[i].question}`);
    if (userAnswer === null) {
      showOutput("Quiz cancelled.");
      return;
    }
    if (userAnswer.trim().toLowerCase() === questions[i].answer) {
      score++;
      alert("Correct!");
    } else {
      alert(`Incorrect. Correct answer: ${questions[i].answer}`);
    }
  }

  let grade;
  let result;
  if (score === 3) {
    grade = "A";
    result = "Excellent!";
  } else if (score === 2) {
    grade = "B";
    result = "Good work!";
  } else if (score === 1) {
    grade = "C";
    result = "Keep practising!";
  } else {
    grade = "No grade";
    result = "Please revise and try again.";
  }
  showOutput(`QUIZ RESULT\nYour score: ${score}/3\nGrade: ${grade}\n${result}`);
}

// 7. Dynamic Movie / Shopping Wishlist Manager
function wishlistManager() {
  const wishlist = ["Interstellar", "Inception", "The Dark Knight"];
  let running = true;

  while (running) {
    const choice = prompt(
      `WISHLIST\n${wishlist.map((item, index) => `${index + 1}. ${item}`).join("\n")}\n\nChoose an action:\n1 = Add at end (push)\n2 = Add at beginning (unshift)\n3 = Remove last (pop)\n4 = Remove first (shift)\n5 = Insert at position (splice)\n6 = Delete at position (splice)\n7 = Exit`
    );
    if (choice === null || choice === "7") break;

    if (choice === "1" || choice === "2") {
      const item = prompt("Enter the item name:");
      if (item && item.trim()) {
        if (choice === "1") wishlist.push(item.trim());
        else wishlist.unshift(item.trim());
      }
    } else if (choice === "3") {
      const removed = wishlist.pop();
      alert(removed ? `Removed: ${removed}` : "The wishlist is empty.");
    } else if (choice === "4") {
      const removed = wishlist.shift();
      alert(removed ? `Removed: ${removed}` : "The wishlist is empty.");
    } else if (choice === "5") {
      const position = getNumber(`Insert at which position? (1 to ${wishlist.length + 1})`);
      if (position === null || !Number.isInteger(position) || position < 1 || position > wishlist.length + 1) {
        alert("Invalid position.");
        continue;
      }
      const item = prompt("Enter the new item:");
      if (item && item.trim()) wishlist.splice(position - 1, 0, item.trim());
    } else if (choice === "6") {
      if (wishlist.length === 0) {
        alert("The wishlist is empty.");
        continue;
      }
      const position = getNumber(`Delete which position? (1 to ${wishlist.length})`);
      if (position === null || !Number.isInteger(position) || position < 1 || position > wishlist.length) {
        alert("Invalid position.");
        continue;
      }
      const removed = wishlist.splice(position - 1, 1);
      alert(`Deleted: ${removed[0]}`);
    } else {
      alert("Please choose a number from 1 to 7.");
    }
  }

  showOutput(`FINAL WISHLIST\n${wishlist.length ? wishlist.map((item, index) => `${index + 1}. ${item}`).join("\n") : "Your wishlist is empty."}`);
}

// 8. City Finder & Search Engine (for loop + flag)
function cityFinder() {
  const cities = ["Karachi", "Lahore", "Islamabad", "Peshawar", "Quetta", "Multan"];
  const searchCity = prompt(`Enter a city name:\nAvailable examples: ${cities.join(", ")}`);
  if (searchCity === null || searchCity.trim() === "") return;

  let matchFound = false;
  for (let i = 0; i < cities.length; i++) {
    if (cities[i].toLowerCase() === searchCity.trim().toLowerCase()) {
      matchFound = true;
      break;
    }
  }

  showOutput(matchFound ? `${searchCity.trim()}: City found!` : `${searchCity.trim()}: City not found.`);
}

// 9. Custom Multiplication Table Generator
function multiplicationTable() {
  const number = getNumber("Enter a number for its multiplication table:");
  if (number === null) return;
  const range = getNumber("How far should the table go? (e.g. 10)");
  if (range === null || !Number.isInteger(range) || range < 1 || range > 100) {
    alert("Enter a whole number from 1 to 100 for the range.");
    return;
  }

  let table = `MULTIPLICATION TABLE OF ${number}\n`;
  for (let i = 1; i <= range; i++) {
    table += `${number} × ${i} = ${number * i}\n`;
  }
  showOutput(table.trimEnd());
}

// 10. Nested Loop Star Pattern Generator
function starPattern() {
  const rows = getNumber("Enter the number of rows (1 to 20):");
  if (rows === null || !Number.isInteger(rows) || rows < 1 || rows > 20) {
    alert("Enter a whole number from 1 to 20.");
    return;
  }
  const shapeInput = prompt("Choose pattern: triangle or square");
  if (shapeInput === null) return;
  const shape = shapeInput.trim().toLowerCase();
  let pattern = "";

  if (shape === "triangle") {
    for (let i = 1; i <= rows; i++) {
      for (let j = 1; j <= i; j++) {
        pattern += "* ";
      }
      pattern += "\n";
    }
  } else if (shape === "square") {
    for (let i = 1; i <= rows; i++) {
      for (let j = 1; j <= rows; j++) {
        pattern += "* ";
      }
      pattern += "\n";
    }
  } else {
    showOutput("Invalid pattern. Please enter triangle or square.");
    return;
  }
  showOutput(pattern.trimEnd());
}
