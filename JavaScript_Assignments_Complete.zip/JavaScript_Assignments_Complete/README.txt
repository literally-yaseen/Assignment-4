JAVASCRIPT ASSIGNMENTS — COMPLETE PROJECT

Included:
1. Smart Profile & Birth Year Calculator
2. Smart Supermarket Bill Splitter
3. Interactive CLI Calculator
4. Movie Ticket Discount & VIP Pass System
5. Time-Based Greeting
6. Interactive Quiz & Grade System
7. Wishlist Manager (push, pop, shift, unshift, splice)
8. City Finder (for loop + Boolean flag)
9. Multiplication Table Generator
10. Nested Loop Star Pattern Generator

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in Chrome or another modern browser.
3. Click any assignment button.
4. Answer the browser prompts.
5. Read the result in the output panel.

NOTES
- All assignment logic is in script.js.
- This project uses prompt() for input and displays results directly in the output panel below the assignment cards (not in the console).
- The birth year is an estimate based on age and current year; exact birth year depends on whether the user's birthday has occurred this year.
- The ticket system uses Rs. 1000 as the standard ticket price, Rs. 300 as the child ticket price, and VIP2026 as the sample promo code. You can change these values in script.js.
